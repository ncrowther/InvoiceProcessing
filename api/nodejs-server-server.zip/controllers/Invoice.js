'use strict';

var utils = require('../utils/writer.js');
var Invoice = require('../service/InvoiceService');

module.exports.sendInvoice = function sendInvoice (req, res, next, body) {
  Invoice.sendInvoice(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.sendInvoice = function sendInvoice (req, res, next, body) {
  Invoice.sendInvoice(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
