'use strict';


/**
 * Send invoice to be validated
 * Send an invoice
 *
 * body Invoice Send an invoice
 * returns Invoice
 **/
exports.sendInvoice = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "lineItems" : [ {
    "productCode" : "productCode",
    "decription" : "decription",
    "quantity" : "quantity",
    "totalPrice" : "totalPrice",
    "vat" : "vat",
    "netPrice" : "netPrice",
    "units" : "units"
  }, {
    "productCode" : "productCode",
    "decription" : "decription",
    "quantity" : "quantity",
    "totalPrice" : "totalPrice",
    "vat" : "vat",
    "netPrice" : "netPrice",
    "units" : "units"
  } ],
  "totalAmount" : "10.45",
  "invoiceNumber" : "INV9873498",
  "invoiceDate" : "15/06/1967"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Send invoice to be validated
 * Send an invoice
 *
 * body Invoice Send an invoice
 * returns Invoice
 **/
exports.sendInvoice = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "lineItems" : [ {
    "productCode" : "productCode",
    "decription" : "decription",
    "quantity" : "quantity",
    "totalPrice" : "totalPrice",
    "vat" : "vat",
    "netPrice" : "netPrice",
    "units" : "units"
  }, {
    "productCode" : "productCode",
    "decription" : "decription",
    "quantity" : "quantity",
    "totalPrice" : "totalPrice",
    "vat" : "vat",
    "netPrice" : "netPrice",
    "units" : "units"
  } ],
  "totalAmount" : "10.45",
  "invoiceNumber" : "INV9873498",
  "invoiceDate" : "15/06/1967"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

